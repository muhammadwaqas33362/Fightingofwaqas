import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen Dimensions
WIDTH, HEIGHT = 800, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Fighting Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Clock for FPS
clock = pygame.time.Clock()
FPS = 60

# Player Properties
player_width, player_height = 50, 60
player1 = pygame.Rect(100, HEIGHT - player_height - 10, player_width, player_height)
player2 = pygame.Rect(WIDTH - 150, HEIGHT - player_height - 10, player_width, player_height)

player1_health = 100
player2_health = 100

# Velocities
player_velocity = 5
punch_velocity = 10

# Fonts
font = pygame.font.Font(None, 36)

def draw_health():
    """Draws health bars for players."""
    pygame.draw.rect(screen, RED, (50, 20, player1_health * 2, 20))
    pygame.draw.rect(screen, BLUE, (WIDTH - 250, 20, player2_health * 2, 20))

def handle_movement(keys, player, left, right, up, down):
    """Handles movement for players."""
    if keys[left] and player.x - player_velocity > 0:
        player.x -= player_velocity
    if keys[right] and player.x + player_velocity < WIDTH - player_width:
        player.x += player_velocity
    if keys[up] and player.y - player_velocity > 0:
        player.y -= player_velocity
    if keys[down] and player.y + player_velocity < HEIGHT - player_height:
        player.y += player_velocity

def handle_punch(player, opponent, is_punching):
    """Handles punching logic."""
    global player1_health, player2_health
    if is_punching and player.colliderect(opponent):
        if player == player1:
            player2_health -= 10
        else:
            player1_health -= 10

def draw():
    """Draws everything on the screen."""
    screen.fill(WHITE)
    
    # Draw players
    pygame.draw.rect(screen, RED, player1)
    pygame.draw.rect(screen, BLUE, player2)

    # Draw health bars
    draw_health()

    # Draw health text
    health_text_1 = font.render(f"Player 1 Health: {player1_health}", True, BLACK)
    health_text_2 = font.render(f"Player 2 Health: {player2_health}", True, BLACK)
    screen.blit(health_text_1, (50, 50))
    screen.blit(health_text_2, (WIDTH - 250, 50))

    pygame.display.flip()

# Main Game Loop
running = True
while running:
    clock.tick(FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    # Player 1 Movement
    handle_movement(keys, player1, pygame.K_a, pygame.K_d, pygame.K_w, pygame.K_s)

    # Player 2 Movement
    handle_movement(keys, player2, pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN)

    # Player 1 Punch
    handle_punch(player1, player2, keys[pygame.K_SPACE])

    # Player 2 Punch
    handle_punch(player2, player1, keys[pygame.K_RETURN])

    # Check for Game Over
    if player1_health <= 0 or player2_health <= 0:
        winner = "Player 1" if player2_health <= 0 else "Player 2"
        print(f"{winner} wins!")
        running = False

    draw()

pygame.quit()
sys.exit()
