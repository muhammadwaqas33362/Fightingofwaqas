# Fighting Game

This is a simple 2D fighting game built with Python and Pygame.

## Features
- Two players can fight each other.
- Health bars display remaining health.
- Game ends when one player's health reaches 0.

## Controls
### Player 1
- Move: `W`, `A`, `S`, `D`
- Punch: `Space`

### Player 2
- Move: Arrow keys
- Punch: `Enter`

## Requirements
- Python 3.x
- Pygame library (`pip install pygame`)

## Running the Game
1. Install the requirements.
2. Run the `fighting_game.py` script.
```bash
python fighting_game.py
```

Enjoy the game!
